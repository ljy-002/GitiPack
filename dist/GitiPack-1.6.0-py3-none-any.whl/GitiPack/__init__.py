from .tig import *
# 调用文件

# import tig

# tig.ctig()
# tig.webg()

# a = tig.ctime()
# print(a)
